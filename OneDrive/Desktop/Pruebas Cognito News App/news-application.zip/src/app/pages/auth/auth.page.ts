import { Component, OnInit, inject } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { User } from 'src/app/models/user.model';
import { FirebaseService } from 'src/app/services/firebase.service';
import { UtilsService } from 'src/app/services/utils.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.page.html',
  styleUrls: ['./auth.page.scss'],
})
export class AuthPage implements OnInit {
  form = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required]),
  });

  firebaseSvc = inject(FirebaseService);
  utilsSvc = inject(UtilsService);
  userSvc = inject(UserService);

  ngOnInit() {}

  /**
   * @function submit
   * @description Funcion para permitir al usuario realizar ingresar en la aplicacion al hacer click en el 
   * boton 'Ingresar'
   */
  async submit() {
    if(this.form.valid) {
      const loading = await this.utilsSvc.loading();
      await loading.present();
      this.firebaseSvc.signIn(this.form.value as User).then((res) => {

        this.getUserInfo(res.user.uid);
      }).catch(error => {
        console.log(error);
        
        this.utilsSvc.presentToast({
          message: `Error al querer ingresar al sistema por credenciales invalidas`,
          duration: 2000,
          color: 'primary',
          position: 'middle',
          icon: 'alert.circle.outline'
        })
      }).finally(() => {
        loading.dismiss();
      })
    }
  }

  /**
   * @function getUserInfo
   * @description Funcion con logica para obtener datos del usuario de la bbdd y hacer la autheticacion 
   * del mismo
   * @param uuid 
   */
  async getUserInfo(uuid: string) {
    if (this.form.valid) {
      const loading = await this.utilsSvc.loading();
      await loading.present();

      let path = `users/${uuid}`;

      this.firebaseSvc.getDocument(path).then((user: User) => {
          this.utilsSvc.saveInLocalStorage('user', user);
          this.userSvc.setUser(user);
          this.utilsSvc.routerLink('/tabs');
          this.form.reset();

          this.utilsSvc.presentToast({
            message: `Bienvenido al sistema ${user.name}!`,
            duration: 1500,
            color: 'primary',
            position: 'middle',
            icon: 'person-circle-outline',
          });
        })
        .catch((error) => {
          console.log(error);

          this.utilsSvc.presentToast({
            message: error.message,
            duration: 2500,
            color: 'primary',
            position: 'middle',
            icon: 'alert-circle-outline',
          });
        })
        .finally(() => {
          loading.dismiss();
        });
    }
  }
}
