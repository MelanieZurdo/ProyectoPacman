export const environment = {
  production: true,
  firebaseConfig: { 
    apiKey: "AIzaSyBj_tF0s_a8i2d177zzTi58ZQV9AgdIXrw",
    authDomain: "newsapp-9172e.firebaseapp.com",
    projectId: "newsapp-9172e",
    storageBucket: "newsapp-9172e.appspot.com",
    messagingSenderId: "323491723120",
    appId: "1:323491723120:web:c204a5a4535f7e0b4081b5"
  },
  apiKey: '2271337e71254b8b985080fb30abb9fc',
};
